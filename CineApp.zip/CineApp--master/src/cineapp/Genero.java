package cineapp;

public enum Genero {

	DRAMA, COMEDIA, MUSICAL, AVENTURAS, TERROR, INFANTIL;
	
}
